﻿namespace Inventory_Management_C968
{
    public class Inhouse : Part
    {
        private int machineID;
        public override int MachineID
        {
            get
            {
                return GetMachineID();
            }
            set
            {
                SetMachineID(value);
            }
        }


        public Inhouse(string name, int inventory, double price, int min, int max, int machineID)
            : base(name, inventory, price, min, max)
        {
            MachineID = machineID;
        }
        public Inhouse(int partID, string name, int inventory, double price, int min, int max, int machineID)
            : base(partID, name, inventory, price, min, max)
        {
            MachineID = machineID;
        }

        public void SetMachineID(int machineID)
        {
            this.machineID = machineID;
        }
        public override int GetMachineID()
        {
            return machineID;
        }

    }
}
