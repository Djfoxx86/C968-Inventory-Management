﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Inventory_Management_C968
{
    public class Inventory
    {
        public static List<Product> Products = new List<Product>();
        public static List<Part> Parts = new List<Part>();

        public static int nextPartID = 0;
        public static int nextProductID = 0;

        public static int GetNextPartID()
        {
            return nextPartID++;
        }
        public static int GetNextProductID()
        {
            return nextProductID++;
        }
        public static void AddProduct(Product product)
        {
            Products.Add(product);
        }
        public static bool RemoveProduct(int productID)
        {
            try
            {
                Products.Remove(LookupProduct(productID));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static Product LookupProduct(int productID)
        {
            foreach (Product product in Products)
            {
                if (product.GetProductID() == productID)
                {
                    return product;
                }
            }
            return null;
        }
        public static void UpdateProduct(int productID, Product replacement)
        {
            Product oldProduct = Products.Where(i => i.ProductID == productID).First();
            var index = Products.IndexOf(oldProduct);

            if (index != -1)
                Products[index] = replacement;

            oldProduct = replacement;
        }
        public static void AddPart(Part part)
        {
            Parts.Add(part);
        }
        public static bool Deletepart(Part part)
        {
            try
            {
                Parts.Remove(LookupPart(part.GetPartId()));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static Part LookupPart(int partID)
        {
            foreach (Part part in Parts)
            {
                if (part.GetPartId() == partID)
                {
                    return part;
                }
            }
            return null;
        }
        public static void UpdatePart(int partID, Part replacement)
        {
            Part oldPart = Parts.Where(i => i.PartID == partID).First();
            var index = Parts.IndexOf(oldPart);

            if (index != -1)
                Parts[index] = replacement;
                

            oldPart = replacement;

        }

    }
}
