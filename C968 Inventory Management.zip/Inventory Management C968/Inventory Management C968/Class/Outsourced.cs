﻿namespace Inventory_Management_C968
{
    public class Outsourced : Part
    {
        private string companyName;
        public override string CompanyName
        {
            get
            {
                return GetCompanyName();
            }
            set
            {
                SetCompanyName(value);
            }
        }


        public Outsourced(string name, int inventory, double price, int min, int max, string companyName)
            : base(name, inventory, price, min, max)
        {
            CompanyName = companyName;
        }
        public Outsourced(int partID, string name, int inventory, double price, int min, int max, string companyName)
            : base(partID, name, inventory, price, min, max)
        {
            CompanyName = companyName;
        }

        public void SetCompanyName(string companyName)
        {
            this.companyName = companyName;
        }
        public override string GetCompanyName()
        {
            return companyName;
        }
    }
}
