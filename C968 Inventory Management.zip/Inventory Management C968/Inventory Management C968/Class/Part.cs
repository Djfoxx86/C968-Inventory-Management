﻿using System;

namespace Inventory_Management_C968
{
    public abstract class Part
    {
        private int partID;
        public int PartID
        {
            get { return GetPartId(); }
            set { SetPartId(value); }
        }
        private string name;
        public string Name { get; set; }

        private int inventory;
        public int Inventory { get; set; }

        private double price;
        public double Price { get; set; }

        private int min;
        public int Min { get; set; }

        private int max;
        public int Max { get; set; }

        public virtual int MachineID { get; set; }
        public virtual string CompanyName { get; set; }


        public Part(string name, int inventory, double price, int min, int max)
            : this(Inventory_Management_C968.Inventory.GetNextPartID(), name, inventory, price, min, max) { }

        public Part(int partID, string name, int inventory, double price, int min, int max)
        {
            PartID = partID;
            Name = name;
            Inventory = inventory;
            Price = price;
            Min = min;
            Max = max;
        }
        //Getters

        public int GetPartId()
        {
            return partID;
        }
        public string GetName()
        {
            return name;
        }
        public int GetInventory()
        {
            return inventory;
        }
        public double GetPrice()
        {
            return price;
        }
        public int GetMin()
        {
            return min;
        }
        public int GetMax()
        {
            return max;
        }

        //Setters

        public void SetPartId(int partID)
        {
            this.partID = partID;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetInventory(int inventory)
        {
            this.inventory = inventory;
        }
        public void SetPrice(double price)
        {
            if (price <= 0)
            {
                throw new Exception("Price cannot be below $0.00");
            }
            this.price = price;
        }
        public void SetMin(int min)
        {
            this.min = min;
        }
        public void SetMax(int max)
        {
            if (max < min)
            {
                throw new Exception("Max cannot be less than min");
            }
            this.max = max;
        }
        public virtual int GetMachineID() { return 0; }
        public virtual string GetCompanyName() { return ""; }
    }
}
