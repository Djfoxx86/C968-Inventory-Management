﻿using System;
using System.Collections;

namespace Inventory_Management_C968
{
    public class Product
    {
        private readonly ArrayList associatedParts;
        private int productID;
        public int ProductID
        {
            get
            {
                return GetProductID();
            }
            set
            {
                SetProductID(value);
            }
        }
        private string name;
        public string Name
        {
            get
            {
                return GetName();
            }
            set
            {
                SetName(value);
            }
        }
        private int inventory;
        public int Inventory
        {
            get
            {
                return GetInventory();
            }
            set
            {
                SetInventory(value);
            }
        }
        private double price;
        public double Price
        {
            get
            {
                return GetPrice();
            }
            set
            {
                SetPrice(value);
            }
        }
        private int min;
        public int Min
        {
            get
            {
                return GetMin();
            }
            set
            {
                SetMin(value);
            }
        }
        private int max;
        public int Max
        {
            get
            {
                return GetMax();
            }
            set
            {
                SetMax(value);
            }
        }

        public Product(string name, int inventory, double price, int min, int max, ArrayList associatedParts)
            : this(Inventory_Management_C968.Inventory.GetNextProductID(), name, inventory, price, min, max, associatedParts) { }

        public Product(int productID, string name, int inventory, double price, int min, int max)
        {
            associatedParts = new ArrayList();
            ProductID = productID;
            Name = name;
            Inventory = inventory;
            Price = price;
            Min = min;
            Max = max;
        }
        public Product(int productID, string name, int inventory, double price, int min, int max, ArrayList associatedParts)
            : this(productID, name, inventory, price, min, max)
        {
            this.associatedParts = associatedParts;
        }

        //Getters

        public int GetProductID()
        {
            return productID;
        }
        public ArrayList GetAssociatedParts()
        {
            return associatedParts;
        }
        public string GetName()
        {
            return name;
        }
        public int GetInventory()
        {
            return inventory;
        }
        public double GetPrice()
        {
            return price;
        }
        public int GetMin()
        {
            return min;
        }
        public int GetMax()
        {
            return max;
        }

        //Setters

        public void SetProductID(int productID)
        {
            this.productID = productID;
        }
        public void SetName(string name)
        {
            this.name = name;
        }
        public void SetInventory(int inventory)
        {
            this.inventory = inventory;
        }
        public void SetPrice(double price)
        {
            if (price <= 0)
            {
                throw new Exception("Price must be greater than $0.00");
            }
            this.price = price;
        }
        public void SetMin(int min)
        {
            this.min = min;
        }
        public void SetMax(int max)
        {
            if (max < min)
            {
                throw new Exception("Max cannot be less than min");
            }
            this.max = max;
        }

        //Add Parts
        public void AddAssociatedPart(Part part)
        {
            associatedParts.Add(part);
        }

        //Remove Parts
        public bool RemoveAssociatedPart(int partID)
        {
            try
            {
                associatedParts.Remove(SearchAssociatedPart(partID));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        //Search Parts
        public Part SearchAssociatedPart(int partID)
        {
            foreach (Part part in associatedParts)
            {
                if (part.GetPartId() == partID)
                {
                    return part;
                }
            }
            return null;
        }
    }
}
