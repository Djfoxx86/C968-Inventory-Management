﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Inventory_Management_C968
{

    //This will highlight empty or incorrectly formated fields and send an error msgbox
    public partial class EventHandler : Form
    {
        protected Part part;
        protected Product product;
        protected bool isNew;

        public EventHandler()
        {
            InitializeComponent();
        }

        public virtual void LoadForm()
        {
            this.AutoValidate = AutoValidate.Disable;
            NameInput.CausesValidation = true;
            NameInput.Validating += new System.ComponentModel.CancelEventHandler(NameInput_Validating);
            InventoryInput.CausesValidation = true;
            InventoryInput.Validating += new System.ComponentModel.CancelEventHandler(CountInput_Validating);
            PriceInput.CausesValidation = true;
            PriceInput.Validating += new System.ComponentModel.CancelEventHandler(PriceInput_Validating);
            MinCountInput.CausesValidation = true;
            MinCountInput.Validating += new System.ComponentModel.CancelEventHandler(MinCountInput_Validating);
            MaxCountInput.CausesValidation = true;
            MaxCountInput.Validating += new System.ComponentModel.CancelEventHandler(MaxCountInput_Validating);
        }

        private void PartCancelButton_Click(object sender, EventArgs e)
        {
            Hide();
        }
        private void EventHandlerForm_change(object sender, EventArgs e)
        {
            this.FormCancelButton.Location = new System.Drawing.Point(Width - 130, Height - 120);
            this.SaveButton.Location = new System.Drawing.Point(FormCancelButton.Left - SaveButton.Width - 20, FormCancelButton.Top);
        }
        void NameInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel = NameInput.Text.Length == 0;
            if (e.Cancel)
            {
                NameInput.BackColor = Color.Red;
            }
        }
        private void CountInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel = !int.TryParse(InventoryInput.Text, out _);
            if (e.Cancel)
            {
                InventoryInput.BackColor = Color.Red;
            }
        }
        private void PriceInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel = !double.TryParse(PriceInput.Text, out _);
            if (e.Cancel)
            {
                PriceInput.BackColor = Color.Red;
            }
        }
        private void MinCountInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel = !int.TryParse(MinCountInput.Text, out _);
            if (e.Cancel)
            {
                MinCountInput.BackColor = Color.Red;
            }
        }
        private void MaxCountInput_Validating(object sender, CancelEventArgs e)
        {
            e.Cancel = !int.TryParse(MaxCountInput.Text, out _);
            if (e.Cancel)
            {
                MaxCountInput.BackColor = Color.Red;
            }
        }
        public virtual void SaveButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
            {
                SaveItem();
            }
            else
            {
                MessageBox.Show(NameInput, "You seem to be missing something! Please fill out the highlighted spaces.");
            }
        }
        public virtual void SaveItem()
        {
            return;
        }

        private void OutsourcedRadio_CheckedChanged(object sender, EventArgs e)
        {
            SourceLabel.Text = (OutsourcedRadio.Checked) ? "Company Name" : "Machine ID";
        }


    }
}
