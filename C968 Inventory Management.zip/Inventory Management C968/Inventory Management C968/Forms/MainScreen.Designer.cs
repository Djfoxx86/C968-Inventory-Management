﻿namespace Inventory_Management_C968
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param Name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.AddProductButton = new System.Windows.Forms.Button();
            this.ModifyProductButton = new System.Windows.Forms.Button();
            this.DeleteProductButton = new System.Windows.Forms.Button();
            this.PartsDataGrid = new System.Windows.Forms.DataGridView();
            this.ProductsDataGrid = new System.Windows.Forms.DataGridView();
            this.ProductSearchInput = new System.Windows.Forms.TextBox();
            this.ProductSearchButton = new System.Windows.Forms.Button();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.appName = new Inventory_Management_C968.CustomControls.PageLabel();
            this.PartsSearchButton = new System.Windows.Forms.Button();
            this.PartSearchInput = new System.Windows.Forms.TextBox();
            this.DeletePartButton = new System.Windows.Forms.Button();
            this.ModifyPartButton = new System.Windows.Forms.Button();
            this.AddPartButton = new System.Windows.Forms.Button();
            this.partsLabel = new System.Windows.Forms.Label();
            this.productLable = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PartsDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.exitButton.Location = new System.Drawing.Point(1219, 654);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(148, 32);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // AddProductButton
            // 
            this.AddProductButton.AutoSize = true;
            this.AddProductButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.AddProductButton.Location = new System.Drawing.Point(1081, 538);
            this.AddProductButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.AddProductButton.Name = "AddProductButton";
            this.AddProductButton.Size = new System.Drawing.Size(88, 36);
            this.AddProductButton.TabIndex = 5;
            this.AddProductButton.Text = "Add";
            this.AddProductButton.UseVisualStyleBackColor = false;
            this.AddProductButton.Click += new System.EventHandler(this.AddProductButton_Click);
            // 
            // ModifyProductButton
            // 
            this.ModifyProductButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ModifyProductButton.Location = new System.Drawing.Point(1177, 538);
            this.ModifyProductButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ModifyProductButton.Name = "ModifyProductButton";
            this.ModifyProductButton.Size = new System.Drawing.Size(88, 36);
            this.ModifyProductButton.TabIndex = 6;
            this.ModifyProductButton.Text = "Modify";
            this.ModifyProductButton.UseVisualStyleBackColor = false;
            this.ModifyProductButton.Click += new System.EventHandler(this.ModifyProductButton_Click);
            // 
            // DeleteProductButton
            // 
            this.DeleteProductButton.AutoSize = true;
            this.DeleteProductButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.DeleteProductButton.Location = new System.Drawing.Point(1273, 538);
            this.DeleteProductButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DeleteProductButton.Name = "DeleteProductButton";
            this.DeleteProductButton.Size = new System.Drawing.Size(93, 36);
            this.DeleteProductButton.TabIndex = 7;
            this.DeleteProductButton.Text = "Remove";
            this.DeleteProductButton.UseVisualStyleBackColor = false;
            this.DeleteProductButton.Click += new System.EventHandler(this.DeleteProductButton_Click);
            // 
            // PartsDataGrid
            // 
            this.PartsDataGrid.AllowUserToAddRows = false;
            this.PartsDataGrid.AllowUserToDeleteRows = false;
            this.PartsDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PartsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PartsDataGrid.Location = new System.Drawing.Point(56, 218);
            this.PartsDataGrid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PartsDataGrid.MultiSelect = false;
            this.PartsDataGrid.Name = "PartsDataGrid";
            this.PartsDataGrid.ReadOnly = true;
            this.PartsDataGrid.RowHeadersVisible = false;
            this.PartsDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PartsDataGrid.ShowEditingIcon = false;
            this.PartsDataGrid.Size = new System.Drawing.Size(623, 302);
            this.PartsDataGrid.TabIndex = 2;
            // 
            // ProductsDataGrid
            // 
            this.ProductsDataGrid.AllowUserToAddRows = false;
            this.ProductsDataGrid.AllowUserToDeleteRows = false;
            this.ProductsDataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ProductsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ProductsDataGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ProductsDataGrid.Location = new System.Drawing.Point(743, 218);
            this.ProductsDataGrid.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ProductsDataGrid.MultiSelect = false;
            this.ProductsDataGrid.Name = "ProductsDataGrid";
            this.ProductsDataGrid.ReadOnly = true;
            this.ProductsDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ProductsDataGrid.ShowEditingIcon = false;
            this.ProductsDataGrid.Size = new System.Drawing.Size(623, 302);
            this.ProductsDataGrid.TabIndex = 2;
            // 
            // ProductSearchInput
            // 
            this.ProductSearchInput.Location = new System.Drawing.Point(1160, 160);
            this.ProductSearchInput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ProductSearchInput.Name = "ProductSearchInput";
            this.ProductSearchInput.Size = new System.Drawing.Size(206, 23);
            this.ProductSearchInput.TabIndex = 1;
            this.ProductSearchInput.Text = "Enter Product ID";
            this.ProductSearchInput.Enter += new System.EventHandler(this.ProductSearchInput_Enter);
            this.ProductSearchInput.Leave += new System.EventHandler(this.ProductSearchInput_Leave);
            // 
            // ProductSearchButton
            // 
            this.ProductSearchButton.AutoSize = true;
            this.ProductSearchButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ProductSearchButton.Location = new System.Drawing.Point(1050, 160);
            this.ProductSearchButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ProductSearchButton.Name = "ProductSearchButton";
            this.ProductSearchButton.Size = new System.Drawing.Size(84, 25);
            this.ProductSearchButton.TabIndex = 0;
            this.ProductSearchButton.Text = "Search";
            this.ProductSearchButton.UseVisualStyleBackColor = false;
            this.ProductSearchButton.Click += new System.EventHandler(this.ProductSearchButton_Click);
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 82;
            // 
            // inventoryDataGridViewTextBoxColumn
            // 
            this.inventoryDataGridViewTextBoxColumn.DataPropertyName = "Inventory";
            this.inventoryDataGridViewTextBoxColumn.HeaderText = "Inventory";
            this.inventoryDataGridViewTextBoxColumn.Name = "inventoryDataGridViewTextBoxColumn";
            this.inventoryDataGridViewTextBoxColumn.Width = 81;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 82;
            // 
            // appName
            // 
            this.appName.AutoSize = true;
            this.appName.BackColor = System.Drawing.Color.Transparent;
            this.appName.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.appName.ForeColor = System.Drawing.SystemColors.InfoText;
            this.appName.Location = new System.Drawing.Point(30, 30);
            this.appName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.appName.Name = "appName";
            this.appName.Size = new System.Drawing.Size(283, 25);
            this.appName.TabIndex = 0;
            this.appName.Text = "Inventory Management System";
            this.appName.Click += new System.EventHandler(this.AppTitle_Click);
            // 
            // PartsSearchButton
            // 
            this.PartsSearchButton.AutoSize = true;
            this.PartsSearchButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.PartsSearchButton.Location = new System.Drawing.Point(367, 162);
            this.PartsSearchButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PartsSearchButton.Name = "PartsSearchButton";
            this.PartsSearchButton.Size = new System.Drawing.Size(84, 25);
            this.PartsSearchButton.TabIndex = 0;
            this.PartsSearchButton.Text = "Search";
            this.PartsSearchButton.UseVisualStyleBackColor = false;
            this.PartsSearchButton.Click += new System.EventHandler(this.PartsSearchButton_Click);
            // 
            // PartSearchInput
            // 
            this.PartSearchInput.Location = new System.Drawing.Point(473, 162);
            this.PartSearchInput.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.PartSearchInput.Name = "PartSearchInput";
            this.PartSearchInput.Size = new System.Drawing.Size(206, 23);
            this.PartSearchInput.TabIndex = 1;
            this.PartSearchInput.Text = "Enter Part ID";
            this.PartSearchInput.TextChanged += new System.EventHandler(this.PartSearchInput_TextChanged);
            this.PartSearchInput.Enter += new System.EventHandler(this.PartSearchInput_Enter);
            this.PartSearchInput.Leave += new System.EventHandler(this.PartSearchInput_Leave);
            // 
            // DeletePartButton
            // 
            this.DeletePartButton.AutoSize = true;
            this.DeletePartButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.DeletePartButton.Location = new System.Drawing.Point(586, 538);
            this.DeletePartButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.DeletePartButton.Name = "DeletePartButton";
            this.DeletePartButton.Size = new System.Drawing.Size(93, 36);
            this.DeletePartButton.TabIndex = 7;
            this.DeletePartButton.Text = "Remove";
            this.DeletePartButton.UseVisualStyleBackColor = false;
            this.DeletePartButton.Click += new System.EventHandler(this.DeletePartButton_Click);
            // 
            // ModifyPartButton
            // 
            this.ModifyPartButton.AutoSize = true;
            this.ModifyPartButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ModifyPartButton.Location = new System.Drawing.Point(490, 538);
            this.ModifyPartButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ModifyPartButton.Name = "ModifyPartButton";
            this.ModifyPartButton.Size = new System.Drawing.Size(88, 36);
            this.ModifyPartButton.TabIndex = 6;
            this.ModifyPartButton.Text = "Modify";
            this.ModifyPartButton.UseVisualStyleBackColor = false;
            this.ModifyPartButton.Click += new System.EventHandler(this.ModifyPartButton_Click);
            // 
            // AddPartButton
            // 
            this.AddPartButton.AutoSize = true;
            this.AddPartButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.AddPartButton.Location = new System.Drawing.Point(394, 538);
            this.AddPartButton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.AddPartButton.Name = "AddPartButton";
            this.AddPartButton.Size = new System.Drawing.Size(88, 36);
            this.AddPartButton.TabIndex = 5;
            this.AddPartButton.Text = "Add";
            this.AddPartButton.UseVisualStyleBackColor = false;
            this.AddPartButton.Click += new System.EventHandler(this.AddPartButton_Click);
            // 
            // partsLabel
            // 
            this.partsLabel.AutoSize = true;
            this.partsLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.partsLabel.Location = new System.Drawing.Point(56, 184);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(46, 21);
            this.partsLabel.TabIndex = 8;
            this.partsLabel.Text = "Parts";
            // 
            // productLable
            // 
            this.productLable.AutoSize = true;
            this.productLable.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.productLable.Location = new System.Drawing.Point(743, 184);
            this.productLable.Name = "productLable";
            this.productLable.Size = new System.Drawing.Size(75, 21);
            this.productLable.TabIndex = 9;
            this.productLable.Text = "Products";
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1399, 725);
            this.ControlBox = false;
            this.Controls.Add(this.productLable);
            this.Controls.Add(this.partsLabel);
            this.Controls.Add(this.AddPartButton);
            this.Controls.Add(this.ModifyPartButton);
            this.Controls.Add(this.DeletePartButton);
            this.Controls.Add(this.PartsDataGrid);
            this.Controls.Add(this.PartSearchInput);
            this.Controls.Add(this.PartsSearchButton);
            this.Controls.Add(this.AddProductButton);
            this.Controls.Add(this.ModifyProductButton);
            this.Controls.Add(this.DeleteProductButton);
            this.Controls.Add(this.ProductsDataGrid);
            this.Controls.Add(this.ProductSearchInput);
            this.Controls.Add(this.ProductSearchButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.appName);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "MainScreen";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "MainScreen";
            this.Activated += new System.EventHandler(this.MainScreen_Activated);
            this.Load += new System.EventHandler(this.MainScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PartsDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductsDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CustomControls.PageLabel appName;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button AddProductButton;
        private System.Windows.Forms.Button ModifyProductButton;
        private System.Windows.Forms.Button DeleteProductButton;
        private System.Windows.Forms.DataGridView ProductsDataGrid;
        private System.Windows.Forms.TextBox ProductSearchInput;
        private System.Windows.Forms.Button ProductSearchButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView PartsDataGrid;
        private System.Windows.Forms.Button PartsSearchButton;
        private System.Windows.Forms.TextBox PartSearchInput;
        private System.Windows.Forms.Button DeletePartButton;
        private System.Windows.Forms.Button ModifyPartButton;
        private System.Windows.Forms.Button AddPartButton;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.Label productLable;
    }
}