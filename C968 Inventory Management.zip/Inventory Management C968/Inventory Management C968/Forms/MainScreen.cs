﻿
using System;
using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Inventory_Management_C968
{
    public partial class MainScreen : Form
    {
        // This BindingSource binds the list to the DataGridView control.  
        public static BindingSource partsBindingSource = new BindingSource();
        public static BindingList<Part> partsBindingList = new BindingList<Part>(Inventory.Parts);
        public static BindingSource productsBindingSource = new BindingSource();
        public static BindingList<Product> productsBindingList = new BindingList<Product>(Inventory.Products);

        public MainScreen()
        {
            InitializeComponent();
            CreateFiller();
        }

        private void CreateFiller()
        {
            // Filler Data
            
            Inventory.AddPart(new Inhouse("Wheel", 15, 12.11, 5, 25, 1));
            Inventory.AddPart(new Inhouse("Pedal", 11, 8.22, 5, 25, 2));
            Inventory.AddPart(new Outsourced("Chain", 12, 8.33, 5, 25, "WGU Edu"));
            Inventory.AddPart(new Inhouse("Seat", 8, 4.55, 0, 2, 15));


            Inventory.AddProduct(new Product("Red Bicycle", 15, 11.44, 1, 25, new ArrayList()));
            Inventory.AddProduct(new Product("Yellow Bicycle", 19, 9.66, 1, 20, new ArrayList()));
            Inventory.AddProduct(new Product("Blue Bicycle", 5, 12.77, 1, 25, new ArrayList()));

            Product p1 = Inventory.LookupProduct(0);
            Product p2 = Inventory.LookupProduct(1);
            p1.AddAssociatedPart(Inventory.LookupPart(2));
            p1.AddAssociatedPart(Inventory.LookupPart(0));
            p1.AddAssociatedPart(Inventory.LookupPart(3));
            p2.AddAssociatedPart(Inventory.LookupPart(2));
            p2.AddAssociatedPart(Inventory.LookupPart(1));
            
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddPartButton_Click(object sender, EventArgs e)
        {
            PartsMgmt partForm = new PartsMgmt()
            {
                MdiParent = this.MdiParent
            };

            partForm.Show();
        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {
            ProductMgmt productForm = new ProductMgmt()
            {
                MdiParent = this.MdiParent
            };
            productForm.Show();
        }

        private void PartsDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            // Bind dataview to AllParts list
            partsBindingSource.DataSource = partsBindingList;
            PartsDataGrid.DataSource = partsBindingSource;
            PartsDataGrid.Columns["Price"].DefaultCellStyle.Format = "c";
            PartsDataGrid.Columns["Price"].HeaderText = "Price";
            PartsDataGrid.Columns["PartID"].HeaderText = "Part ID";
            PartsDataGrid.Columns["Min"].HeaderText = "Min";
            PartsDataGrid.Columns["Max"].HeaderText = "Max";
            PartsDataGrid.Columns["CompanyName"].Visible = false;
            PartsDataGrid.Columns["MachineID"].Visible = false;
            PartsDataGrid.RowHeadersVisible = false;


            // Bind dataview to Product list
            productsBindingSource.DataSource = productsBindingList;
            ProductsDataGrid.DataSource = productsBindingSource;
            ProductsDataGrid.Columns["Price"].DefaultCellStyle.Format = "c";
            ProductsDataGrid.Columns["Price"].HeaderText = "Price";
            ProductsDataGrid.Columns["Min"].HeaderText = "Min";
            ProductsDataGrid.Columns["Max"].HeaderText = "Max";
            ProductsDataGrid.RowHeadersVisible = false;
        }

        //private DataGridViewRow selectedRow;
        private void ModifyPartButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = PartsDataGrid.SelectedRows[0];
                var idVal = selectedRow.Cells["PartID"].Value;

                if (idVal.Equals(null))
                {
                    throw new NullReferenceException("Selected row contains null value for partID");
                }
                int partID = Convert.ToInt32(selectedRow.Cells["PartID"].Value);
                Part part = Inventory.LookupPart(partID);

                PartsMgmt partForm = new PartsMgmt(part)
                {
                    MdiParent = this.MdiParent
                };
                partForm.Show();
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Selected row contains null value for partID");
                return;
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("No parts exist to modify.");
            }



        }

        private void ModifyProductButton_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = ProductsDataGrid.SelectedRows[0];

            int productID = Convert.ToInt32(selectedRow.Cells["ProductID"].Value);
            Product product = Inventory.LookupProduct(productID);

            ProductMgmt productForm = new ProductMgmt(product)
            {
                MdiParent = this.MdiParent
            };
            productForm.Show();
        }

        private void MainScreenForm_Refresh(object sender, EventArgs e)
        {
            PartsDataGrid.Invalidate();
            ProductsDataGrid.Invalidate();
            productsBindingSource.ResetBindings(true);
            partsBindingSource.ResetBindings(true);
        }

        private void DebugParts_Click(object sender, EventArgs e)
        {
            StringBuilder message = new StringBuilder();
            foreach (Part part in Inventory.Parts)
            {
                message.AppendLine($"{part.GetName()}");
            }
            MessageBox.Show(message.ToString());
        }

        private void DeletePartButton_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = PartsDataGrid.SelectedRows[0];
            int partID = Convert.ToInt32(selectedRow.Cells["PartID"].Value);
            Part partToDelete = Inventory.LookupPart(partID);
            Inventory.Deletepart(partToDelete);
            RefreshDataGridViews();
        }

        private void RefreshDataGridViews()
        {
            partsBindingSource.ResetBindings(true);
            ModifyPartButton.Enabled = !Inventory.Parts.Count().Equals(0);
            productsBindingSource.ResetBindings(true);
            ModifyProductButton.Enabled = !Inventory.Products.Count().Equals(0);
        }

        private void MainScreen_Activated(object sender, EventArgs e)
        {
            RefreshDataGridViews();
        }

        private void PartsSearchButton_Click(object sender, EventArgs e)
        {
            bool found = false;
            if (!int.TryParse(PartSearchInput.Text, out int searchID))
            {
                MessageBox.Show("Part ID must be numeric");
                return;
            }
            foreach (DataGridViewRow row in PartsDataGrid.Rows)
            {
                Part part = (Part)row.DataBoundItem;
                if (part.PartID == searchID)
                {
                    row.Selected = true;
                    found = true;
                    break;
                }
            }
            if (!found) { MessageBox.Show("Part ID not found"); }
        }

        private void ProductSearchButton_Click(object sender, EventArgs e)
        {
            bool found = false;
            if (!int.TryParse(ProductSearchInput.Text, out int searchID))
            {
                MessageBox.Show("Product ID must be numeric");
                return;
            }
            foreach (DataGridViewRow row in ProductsDataGrid.Rows)
            {
                Product product = (Product)row.DataBoundItem;
                if (product.GetProductID() == searchID)
                {
                    row.Selected = true;
                    found = true;
                    break;
                }
            }
            if (!found) { MessageBox.Show("Product ID not found"); }
        }

        private void PartSearchInput_Enter(object sender, EventArgs e)
        {
            PartSearchInput.Text = (PartSearchInput.Text == "Search by Part ID") ? "" : PartSearchInput.Text;
        }

        private void ProductSearchInput_Enter(object sender, EventArgs e)
        {
            ProductSearchInput.Text = (ProductSearchInput.Text == "Search by Product ID") ? "" : ProductSearchInput.Text;
        }

        private void PartSearchInput_Leave(object sender, EventArgs e)
        {
            PartSearchInput.Text = (PartSearchInput.Text == "") ? "Search by Part ID" : PartSearchInput.Text;
        }

        private void ProductSearchInput_Leave(object sender, EventArgs e)
        {
            ProductSearchInput.Text = (ProductSearchInput.Text == "") ? "Search by Product ID" : ProductSearchInput.Text;
        }

        private void DeleteProductButton_Click(object sender, EventArgs e)
        {
            DataGridViewRow selectedRow = ProductsDataGrid.SelectedRows[0];
            int productID = Convert.ToInt32(selectedRow.Cells["ProductID"].Value);
            Product productToDelete = Inventory.LookupProduct(productID);
            try
            {
                if (productToDelete.GetAssociatedParts().Count > 0)
                {
                    throw new Exception();
                }
                Inventory.RemoveProduct(productID);
                RefreshDataGridViews();
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot delete product with parts associated");
                return;
            }

            Inventory.RemoveProduct(productID);
            RefreshDataGridViews();
        }

        private void PartSearchInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void AppTitle_Click(object sender, EventArgs e)
        {

        }
    }
}
