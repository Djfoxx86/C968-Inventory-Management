﻿using System.Windows.Forms;

namespace Inventory_Management_C968
{
    public partial class Parent : Form
    {

        public Parent()
        {
            InitializeComponent();
            var main = new MainScreen
            {
                MdiParent = this
            };
            main.Show();
        }

    }

}
