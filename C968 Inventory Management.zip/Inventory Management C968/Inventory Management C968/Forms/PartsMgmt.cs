﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Inventory_Management_C968
{
    
    public partial class PartsMgmt : EventHandler
    {
        public PartsMgmt()

        {

            InitializeComponent();
            ModPageLabel.Text = "Add Part";
            IDInput.Text = Inventory.nextPartID.ToString();
            IDInput.Enabled = false;
            isNew = true;
            SourceLabel.Text = "Machine ID";
            LoadForm();
        }


        public PartsMgmt(Part part)
        {
            InitializeComponent();
            ModPageLabel.Text = "Modify Part";
            this.part = part;
            isNew = false;
            LoadPart(part);
        }
        public void LoadPart(Part part)
        {
            IDInput.Text = part.PartID.ToString();
            IDInput.Enabled = false;
            NameInput.Text = part.Name;
            InventoryInput.Text = part.Inventory.ToString();
            PriceInput.Text = part.Price.ToString();
            MinCountInput.Text = part.Min.ToString();
            MaxCountInput.Text = part.Max.ToString();
            if (part is Inhouse)
            {
                InHouseRadio.Select();
                SourceLabel.Text = "Machine ID";
                SourceIDInput.Text = part.GetMachineID().ToString();
            }
            else
            {
                OutsourcedRadio.Select();
                SourceLabel.Text = "Company Name";
                SourceIDInput.Text = part.GetCompanyName().ToString();
            }
            LoadForm();


        }
        public override void LoadForm()
        {
            base.LoadForm();
            SourceIDInput.CausesValidation = true;
            SourceIDInput.Validating += new System.ComponentModel.CancelEventHandler(SourceIDInput_Validating);

        }
        private void SourceIDInput_Validating(object sender, CancelEventArgs e)
        {
            if (InHouseRadio.Checked)
            {
                e.Cancel = !int.TryParse(SourceIDInput.Text, out _);
            }
            else
            {
                e.Cancel = SourceIDInput.Text.Length == 0;
            }
            if (e.Cancel)
            {
                SourceIDInput.BackColor = Color.Red;
            }
        }
        public override void SaveItem()
        {
            try
            {
                if (isNew)
                {
                    if (InHouseRadio.Checked)
                    {
                        Inventory.AddPart(new Inhouse(
                                NameInput.Text,
                                Convert.ToInt32(InventoryInput.Text),
                                Convert.ToDouble(PriceInput.Text),
                                Convert.ToInt32(MinCountInput.Text),
                                Convert.ToInt32(MaxCountInput.Text),
                                Convert.ToInt32(SourceIDInput.Text)
                                ));
                    }
                    else
                    {
                        Inventory.AddPart(new Outsourced(
                                NameInput.Text,
                                Convert.ToInt32(InventoryInput.Text),
                                Convert.ToDouble(PriceInput.Text),
                                Convert.ToInt32(MinCountInput.Text),
                                Convert.ToInt32(MaxCountInput.Text),
                                SourceIDInput.Text
                            ));
                    }
                }
                else
                {
                    Part updatedPart;
                    if (InHouseRadio.Checked)
                    {
                        updatedPart = new Inhouse(
                                Convert.ToInt32(IDInput.Text),
                                NameInput.Text,
                                Convert.ToInt32(InventoryInput.Text),
                                Convert.ToDouble(PriceInput.Text),
                                Convert.ToInt32(MinCountInput.Text),
                                Convert.ToInt32(MaxCountInput.Text),
                                Convert.ToInt32(SourceIDInput.Text)
                                );
                    }
                    else
                    {
                        updatedPart = new Outsourced(
                                Convert.ToInt32(IDInput.Text),
                                NameInput.Text,
                                Convert.ToInt32(InventoryInput.Text),
                                Convert.ToDouble(PriceInput.Text),
                                Convert.ToInt32(MinCountInput.Text),
                                Convert.ToInt32(MaxCountInput.Text),
                                SourceIDInput.Text
                                );
                    }

                    Inventory.UpdatePart(Convert.ToInt32(IDInput.Text), updatedPart);
                }
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"A problem occurred during save: {ex.Message}");
                return;
            }

        }

    }
}
