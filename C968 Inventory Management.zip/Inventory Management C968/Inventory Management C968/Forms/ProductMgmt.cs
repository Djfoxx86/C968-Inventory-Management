﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace Inventory_Management_C968
{
    public partial class ProductMgmt : EventHandler
    {
        public BindingSource partsBindingSource = new BindingSource();
        public BindingList<Part> partsBindingList = new BindingList<Part>(Inventory.Parts);
        public BindingSource associatedPartsBindingSource = new BindingSource();
        public BindingList<Part> associatedPartsBindingList = new BindingList<Part>();

        public ProductMgmt(Product product)
        {
            InitializeComponent();
            isNew = false;
            IDInput.Enabled = false;
            ModPageLabel.Text = "Modify Product";
            LoadProduct(product);
            this.product = product;
            LoadForm();
        }

        public ProductMgmt()
        {
            InitializeComponent();
            IDInput.Text = Inventory.nextProductID.ToString();
            IDInput.Enabled = false;
            isNew = true;
            ModPageLabel.Text = "New Product";
            LoadForm();
        }

        public override void LoadForm()
        {

            base.LoadForm();
            SourceIDInput.Hide();
            SourceLabel.Hide();
            InHouseRadio.Hide();
            OutsourcedRadio.Hide();

            //All Existing Parts List
            allPartsListDataGrid.DataSource = partsBindingList;
            allPartsListDataGrid.Columns["Price"].DefaultCellStyle.Format = "c";
            allPartsListDataGrid.Columns["Price"].HeaderText = "Price";
            allPartsListDataGrid.Columns["PartID"].HeaderText = "Part ID";
            allPartsListDataGrid.Columns["Min"].HeaderText = "Min";
            allPartsListDataGrid.Columns["Max"].HeaderText = "Max";
            allPartsListDataGrid.Columns["CompanyName"].Visible = false;
            allPartsListDataGrid.Columns["MachineID"].Visible = false;

            //Parts Associated to Product's Part List
            associatedPartsDataGrid.DataSource = associatedPartsBindingList;
            associatedPartsDataGrid.Columns["Price"].HeaderText = "Price";
            associatedPartsDataGrid.Columns["PartID"].HeaderText = "Part ID";
            associatedPartsDataGrid.Columns["Min"].HeaderText = "Min";
            associatedPartsDataGrid.Columns["Max"].HeaderText = "Max";
            associatedPartsDataGrid.Columns["CompanyName"].Visible = false;
            associatedPartsDataGrid.Columns["MachineID"].Visible = false;
        }

        private void LoadProduct(Product product)
        {

            IDInput.Text = product.GetProductID().ToString();
            IDInput.Enabled = false;
            NameInput.Text = product.GetName();
            InventoryInput.Text = product.GetInventory().ToString();
            PriceInput.Text = product.GetPrice().ToString();
            MinCountInput.Text = product.GetMin().ToString();
            MaxCountInput.Text = product.GetMax().ToString();
            foreach (Part part in product.GetAssociatedParts())
            {
               associatedPartsBindingList.Add(part);
            }



        }

        private void PartSearchInput_Enter(object sender, EventArgs e)
        {

        }

        private void PartSearchButton_Click(object sender, EventArgs e)
        {
            bool found = false;
            if (!int.TryParse(PartSearchInput.Text, out int searchID))
            {
                MessageBox.Show("Part ID must be numeric");
                return;
            }
            foreach (DataGridViewRow row in allPartsListDataGrid.Rows)
            {
                Part part = (Part)row.DataBoundItem;
                if (part.PartID == searchID)
                {
                    row.Selected = true;
                    found = true;
                    break;
                }
            }
            if (!found) { MessageBox.Show("Part ID not found"); }
        }

        private void AddPartButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = allPartsListDataGrid.SelectedRows[0];
                var idVal = selectedRow.Cells["PartID"].Value;

                int partID = Convert.ToInt32(selectedRow.Cells["PartID"].Value);
                Part part = Inventory.LookupPart(partID);

                associatedPartsBindingList.Add(part);
            }

            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("No parts selected.");
            }
            RefreshButtonStates();
        }

        private void DeletePartButton_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow selectedRow = associatedPartsDataGrid.SelectedRows[0];
                int partID = Convert.ToInt32(selectedRow.Cells["PartID"].Value);
                Part partToDelete = Inventory.LookupPart(partID);
                associatedPartsBindingList.Remove(partToDelete);
                RefreshButtonStates();
            }
            catch (Exception)
            {
                MessageBox.Show("No parts are selected.");
            }

        }

        private void RefreshButtonStates()
        {
            DeletePartButton.Enabled = associatedPartsBindingList.Count().Equals(0) ? false : true;
        }

        public override void SaveButton_Click(object sender, EventArgs e)
        {
            base.SaveButton_Click(sender, e);
        }
        public override void SaveItem()
        {
            try
            {
                ArrayList associatedPartsToSave = new ArrayList();
                foreach (Part part in associatedPartsBindingList)
                {
                    associatedPartsToSave.Add(part);
                }

                if (isNew)
                {
                    Inventory.AddProduct(new Product(
                        NameInput.Text,
                        Convert.ToInt32(InventoryInput.Text),
                        Convert.ToDouble(PriceInput.Text),
                        Convert.ToInt32(MinCountInput.Text),
                        Convert.ToInt32(MaxCountInput.Text),
                        associatedPartsToSave
                        ));
                }
                else
                {
                    Product updatedProduct;
                    updatedProduct = new Product(
                            Convert.ToInt32(IDInput.Text),
                            NameInput.Text,
                            Convert.ToInt32(InventoryInput.Text),
                            Convert.ToDouble(PriceInput.Text),
                            Convert.ToInt32(MinCountInput.Text),
                            Convert.ToInt32(MaxCountInput.Text),
                            associatedPartsToSave
                            );
                    Inventory.UpdateProduct(Convert.ToInt32(IDInput.Text), updatedProduct);
                }
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"A problem occurred during save: {ex.Message}");
                return;
            }

        }

        private void AllPartsListDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
