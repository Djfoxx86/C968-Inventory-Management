using System;
using System.Windows.Forms;

/*
 * Student Name: Dustin Rose
 * Student ID: 001109630
 * Course: Software I � C# � C968
 * Date: 12/17/2020
 * Project Name: Inventory Management System
 * */
namespace Inventory_Management_C968
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Parent());
        }
    }
}
